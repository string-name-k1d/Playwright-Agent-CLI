import { test, expect, type Page } from '@playwright/test';
import { revealButton, clickButton, addSection, openAdvancedOptions, expectBlockLabel, publishPage, addTextBlock, toggleBlockAction, removeSectionContaining } from '../../templates/form-helpers';
test.afterEach(async ({ page }, testInfo) => {
  const { mkdirSync } = await import('node:fs');
  const { join } = await import('node:path');
  const dir = process.env.SCREENSHOT_OUTPUT || join(process.cwd(), 'run', 'screenshots');
  try { mkdirSync(dir, { recursive: true }); } catch {}
  const name = testInfo.title.replace(/[^a-z0-9]/gi, '_').toLowerCase();
  const suffix = testInfo.status === 'passed' ? 'pass' : 'fail';
  await page.screenshot({ path: join(dir, name + '_' + suffix + '.png'), fullPage: true }).catch(() => {});
});


async function countExactText(page: Page, text: string): Promise<number> {
  return page.evaluate((t: string) => {
    let c = 0;
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    let node: Node | null;
    while ((node = walker.nextNode())) {
      if (node.textContent?.trim() === t) c++;
    }
    return c;
  }, text);
}

test.describe('People and profile access control', () => {
  test('TC-11 people-and-profile-access-control', async ({ page }) => {
    await page.goto('/admin/people');
    await expect(page).toHaveTitle(/^People \|/);
    await expect(page.locator('h1').first()).toContainText('People');

    await page.goto('/user/1');
    await expect(page.getByText('Member for')).toBeVisible();

    await page.goto('/admin/mtpc/content');
    await page.locator('a[href="/user/1"]').first().click();
    await expect(page).toHaveURL(/\/user\/1/);
    await expect(page.getByText('Member for')).toBeVisible();
  });
});

test.describe('Section and block operations', () => {
  test('TC-12 reorder-sections', async ({ page }) => {
    test.setTimeout(120000);
    const title = 'TC-12 Reorder ' + Date.now();
    await page.goto('/node/add/custom_page/mtpc');
    await page.locator('#edit-title-0-value').fill(title);

    await addSection(page, '1-Column');
    await addTextBlock(page, 0, 'First Section Content');

    await addSection(page, '2-Column');
    await addTextBlock(page, 1, 'Second Section Content');

    await clickButton(page, 'Show row weights');
    await page.waitForTimeout(700);
    await page.locator('select[name="field_mod_sections[0][_weight]"]').selectOption('1');
    await page.locator('select[name="field_mod_sections[1][_weight]"]').selectOption('0');

    const nodeId = await publishPage(page);
    await page.goto('/node/' + nodeId);

    const firstBox = await page.getByText('First Section Content', { exact: true }).first().boundingBox();
    const secondBox = await page.getByText('Second Section Content', { exact: true }).first().boundingBox();
    expect(secondBox!.y).toBeLessThan(firstBox!.y);
  });

  test('TC-13 remove-block-and-section', async ({ page }) => {
    test.setTimeout(120000);
    const title = 'TC-13 Remove ' + Date.now();
    await page.goto('/node/add/custom_page/mtpc');
    await page.locator('#edit-title-0-value').fill(title);

    await addSection(page, '1-Column');
    await addTextBlock(page, 0, 'Keep Me');
    await addTextBlock(page, 0, 'Remove Me');

    await addSection(page, '1-Column');
    await addTextBlock(page, 1, 'Lone Section');

    await toggleBlockAction(page, 'Remove Me', 'Remove');
    await removeSectionContaining(page, 'Lone Section');

    const nodeId = await publishPage(page);
    await page.goto('/node/' + nodeId);

    await expect(page.getByText('Keep Me')).toBeVisible();
    await expect(page.getByText('Remove Me')).toHaveCount(0);
    await expect(page.getByText('Lone Section')).toHaveCount(0);
  });

  test('TC-14 duplicate-block', async ({ page }) => {
    test.setTimeout(120000);
    const title = 'TC-14 Duplicate ' + Date.now();
    await page.goto('/node/add/custom_page/mtpc');
    await page.locator('#edit-title-0-value').fill(title);

    await addSection(page, '1-Column');
    await addTextBlock(page, 0, 'Dupe Me');

    await toggleBlockAction(page, 'Dupe Me', 'Duplicate');

    const taCount = await page.locator('.ck-editor__editable').filter({ hasText: 'Dupe Me' }).count();
    expect(taCount).toBe(2);

    const nodeId = await publishPage(page);
    await page.goto('/node/' + nodeId);

    const rendered = await countExactText(page, 'Dupe Me');
    expect(rendered).toBe(2);
  });

  test('TC-15 two-column-section-both-columns', async ({ page }) => {
    test.setTimeout(120000);
    const title = 'TC-15 Columns ' + Date.now();
    await page.goto('/node/add/custom_page/mtpc');
    await page.locator('#edit-title-0-value').fill(title);

    await addSection(page, '2-Column');
    await addTextBlock(page, 0, 'Left Text', 0);
    await addTextBlock(page, 0, 'Right Text', 1);

    const nodeId = await publishPage(page);
    await page.goto('/node/' + nodeId);

    await expect(page.getByText('Left Text', { exact: true })).toBeVisible();
    await expect(page.getByText('Right Text', { exact: true })).toBeVisible();
  });
});
