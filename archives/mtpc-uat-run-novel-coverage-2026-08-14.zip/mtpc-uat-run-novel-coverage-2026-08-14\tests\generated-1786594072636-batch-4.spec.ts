import { test, expect } from '@playwright/test';
import { revealButton, clickButton, addSection, openAdvancedOptions, expectBlockLabel, publishPage, removeBlock } from '../../templates/form-helpers';
test.afterEach(async ({ page }, testInfo) => {
  const { mkdirSync } = await import('node:fs');
  const { join } = await import('node:path');
  const dir = process.env.SCREENSHOT_OUTPUT || join(process.cwd(), 'run', 'screenshots');
  try { mkdirSync(dir, { recursive: true }); } catch {}
  const name = testInfo.title.replace(/[^a-z0-9]/gi, '_').toLowerCase();
  const suffix = testInfo.status === 'passed' ? 'pass' : 'fail';
  await page.screenshot({ path: join(dir, name + '_' + suffix + '.png'), fullPage: true }).catch(() => {});
});


test('TC-16 second-item-repeatable-blocks', { timeout: 120000 }, async ({ page }) => {
  test.setTimeout(120000);
  const title = 'TC-16 Items ' + Date.now();
  await page.goto('/node/add/custom_page/mtpc');
  await page.locator('#edit-title-0-value').fill(title);

  await addSection(page, '1-Column');

  // Accordion block with two items
  await clickButton(page, 'Add Accordion Block');
  await clickButton(page, 'Add Accordion Item');
  await expect(page.locator('.paragraph-type-label').filter({ hasText: /Accordion Item/i })).toHaveCount(2);
  const accordionItems = page.locator('tr.paragraph-type--mod-accordian-item');
  await accordionItems.nth(0).locator('textarea[name*="field_mtpc_accordion_title"]').fill('Item One');
  await accordionItems.nth(1).locator('textarea[name*="field_mtpc_accordion_title"]').fill('Item Two');

  // Slideshow and carousel items require a media image to be selected, which is
  // out of scope here; verify their second-item add and then remove the blocks
  // so the page can publish with just the accordion.
  await clickButton(page, 'Add Slideshow Block');
  await clickButton(page, 'Add Slideshow Item');
  await expect(page.locator('.paragraph-type-label').filter({ hasText: /Slideshow Item/i })).toHaveCount(2);

  // 3-Column Carousel block with a second item
  await clickButton(page, 'Add 3-Column Carousel Block');
  await clickButton(page, 'Add 3-Col Carousel Item');
  await expect(page.locator('.paragraph-type-label').filter({ hasText: /3-Col Carousel Item/i })).toHaveCount(2);

  await removeBlock(page, 'tr.paragraph-type--mod-slideshow-block', 'SLIDESHOW BLOCK');
  await removeBlock(page, 'tr.paragraph-type--mtpc-3col-carousel-block', '3-COLUMN CAROUSEL BLOCK');

  const nodeId = await publishPage(page);
  await page.goto('/node/' + nodeId);
  await expect(page.getByText('Item One')).toBeVisible();
  await expect(page.getByText('Item Two')).toBeVisible();
});

test('TC-17 empty-title-validation', async ({ page }) => {
  await page.goto('/node/add/custom_page/mtpc');

  // Empty required page title must block publishing.
  await clickButton(page, 'Publish Page');
  await expect(page).toHaveURL(/\/node\/add\/custom_page\/mtpc/);
  await expect(page.locator('#edit-title-0-value')).toBeVisible();

  const title = 'TC-17 Empty ' + Date.now();
  await page.locator('#edit-title-0-value').fill(title);

  // A Page Title block may be added with an empty value (no required error),
  // and publishing then succeeds.
  await addSection(page, '1-Column');
  await clickButton(page, 'Add Page Title Block');

  const nodeId = await publishPage(page);
  await page.goto('/node/' + nodeId);
  await expect(page.locator('h1').first()).toContainText(title);
});

test('TC-18 search-results', async ({ page }) => {
  await page.goto('/search/node');
  const box = page.getByRole('searchbox', { name: /enter your keywords/i });
  await expect(box).toBeVisible();

  await box.fill('Style Guide');
  await page.getByRole('button', { name: 'Search' }).click();
  await expect(page).toHaveURL(/keys=/);
  await expect(page.getByText('Your search yielded no results.')).toBeVisible();

  await page.getByRole('searchbox', { name: /enter your keywords/i }).fill('zzqqxxnotfound');
  await page.getByRole('button', { name: 'Search' }).click();
  await expect(page.getByText('Your search yielded no results.')).toBeVisible();
});

test('TC-19 admin-menu-links-no-404', async ({ page }) => {
  test.setTimeout(180000);
  await page.goto('/');
  await page.getByRole('link', { name: 'MTPC Administration' }).click();
  await expect(page.getByRole('heading', { name: 'Contents', level: 1 })).toBeVisible();

  const hrefs = [
    '/admin/mtpc/content',
    '/node/add/custom_page/mtpc',
    '/admin/mtpc/content?type=news',
    '/node/add/news/mtpc',
    '/admin/mtpc/content?type=mtpc_gallery',
    '/node/add/mtpc_gallery/mtpc',
    '/admin/structure/menu',
    '/admin/content/media',
    '/admin/structure/webform',
    '/admin/config/system/site-information',
  ];
  for (const href of hrefs) {
    await page.goto(href, { timeout: 60000 });
    expect(await page.title()).not.toContain('Page not found');
  }
});

test('TC-20 navigation-menu-block-render', async ({ page }) => {
  test.setTimeout(120000);
  const title = 'TC-20 Nav Menu ' + Date.now();
  await page.goto('/node/add/custom_page/mtpc');
  await page.locator('#edit-title-0-value').fill(title);

  await addSection(page, '1-Column');
  await clickButton(page, 'Add Navigation Menu Block');

  const menuInput = page.locator('input[name*="field_mtpc_nav_menu"]').first();
  await menuInput.fill('Main navigation');
  await page.locator('ul.ui-autocomplete li').first().click();

  await page.locator('select[name*="nav_menu_desk_style"]').selectOption('style1');
  await page.locator('select[name*="nav_menu_mob_style"]').selectOption('dropdown');

  const nodeId = await publishPage(page);
  await page.goto('/node/' + nodeId);

  const main = page.locator('main, #content').first();
  await expect(main.getByRole('link', { name: 'Home', exact: true })).toBeVisible();
  await expect(main.getByRole('link', { name: 'Section One' })).toBeVisible();
  await expect(main.getByRole('link', { name: 'Style Guide' })).toBeVisible();
  await expect(main.getByRole('link', { name: 'Contact us' })).toBeVisible();
});
