# Novel Coverage Autorun: MTPC Drupal Platform (cleaned site)

**Base URL:** `https://builder-clean.docker-uat01.ust.hk/`
**Site:** Drupal Platform Demonstration v10.8 (MTPC content model)

Goal: extend coverage to functions that were NOT exercised by the previous
34-case run. Produce an independent test plan covering every area below that
exists on this site. Prefer breadth over depth: at least one representative
case per area, so the remaining functionality is exercised in one run.

## What the previous run ALREADY covered (do NOT duplicate these)

- Homepage load, skip-to-content link, main-menu navigation, footer + social links
- Member login page, admin toolbar presence (MTPC Administration / Manage / Shortcuts / Logout)
- Content listing load + filter + "created content appears Published"
- Custom page creation with 1/2/3/4-Column sections (add section + publish)
- Advanced Options toggles (Full Width, CSS class, animation, hide on mobile/tablet/desktop, hide page title, hide breadcrumbs)
- Menu settings (provide a menu link, pick menu/parent)
- One add+publish case each for: Text Area, Accordion, Image, Image Grid, Icon & Text Highlight, Slideshow, Video, Youtube/Youku, Page Title, Next & Previous, Views, Navigation Menu, Profile Details, Profile Listing, Events Carousel, 3-Column Carousel
- Album, News, People content-type add forms
- Publishing: every content-creation case ends with Publish Page and asserts redirect / success

## Prerequisites / execution context

- Authenticated session is provided via browser storage state (already logged
  in as an admin user with the toolbar visible). HTTP Basic Auth is supplied
  automatically. Do NOT attempt to log in interactively.
- Each test case must be **fully independent**: start with `page.goto()` to the
  form/page it needs, do minimal setup inside the test itself, never rely on
  state created by another test. Where a test needs a freshly created node, it
  creates it in-test.
- Content-submission cases MUST end by clicking **Publish Page** (or the
  relevant Save/Add button) and asserting the redirect to `/node/<id>` or the
  "has been created" confirmation, so created content is persisted and
  verifiable.
- Rich text is CKEditor 5 — fill via the `Rich Text Editor` role textbox, not
  hidden textareas.
- Sections and block buttons may be hidden behind **List additional actions**;
  the section does NOT exist on page load — click `Add <N>-Column Section` first
  and wait for its wrapper before adding blocks. Publish can be swallowed by
  AJAX re-renders — wait, then retry if the URL stays on /node/add/.
- HTML5 validation silently blocks submits when required fields are empty — fill
  required fields (e.g. the Navigation Menu autocomplete needs the exact token
  `Main navigation (main)` set on its target_id input via JS + change event).

## Coverage areas — functions NOT yet covered (in priority order)

### 1. Published page rendering & lifecycle
- **View a published page:** create (or reuse a link from the content listing)
  a custom page with a section + a Text block, publish, then assert the
  rendered node page (`/node/<id>`) shows the section and its block content,
  and the browser title/heading matches.
- **Edit a published page:** open its node edit form (from the content listing
  "Edit" link), change the title, save/publish, assert the change is reflected
  on the node view.
- **Delete a page:** from the content listing, run a bulk delete (or the node's
  delete tab) on a node created in-test, confirm the confirmation form, assert
  it disappears from the listing.
- **Unpublish/publish a page:** toggle a node's published state from the
  content listing bulk actions or the node form.

### 2. Content listing operations (`/admin/mtpc/content`)
- Sorting (e.g. by Title/Updated) changes row order.
- Bulk action "Publish" / "Unpublish" on a selected row reflects in the STATUS
  column.
- The "Add content" / Custom Menu add links navigate to the right add forms.

### 3. Media management (`/admin/content/media`)
- The media library listing loads with media items (images from earlier runs).
- Upload a new media item (image) via "Add media" — pick the simplest media
  type/upload widget, save, assert it appears in the listing.
- Open a media item's edit form and assert its fields load.

### 4. Structure administration (explore these before planning)
- **Menus** (`/admin/structure/menu`): listing loads; add a menu link to an
  existing menu, assert it is saved and visible in the menu's link list.
- **Content types** (`/admin/structure/types`): listing loads with the MTPC
  content types.
- **Blocks layout** (`/admin/structure/block`): the block placement page loads
  with regions.
- **Views** (`/admin/structure/views`): the views list loads.
- **Taxonomy** (`/admin/structure/taxonomy`): if present, list vocabularies.

### 5. People / users (`/admin/people`)
- The people listing loads with at least the admin user.
- Open a user's profile page (`/user/<uid>` route) and assert it renders.

### 6. Section & block operations on the custom page composer
- **Reorder sections:** add two 1-Column sections, drag/reorder (or use the
  up/down controls if present), assert the order changed.
- **Remove a section / block:** add a section with a block, then remove the
  block via its remove/delete button, assert the block label is gone; then
  remove the section.
- **Duplicate a block:** add a Text block, use its duplicate action if present,
  assert a second copy of the block exists.
- **2-Column section with content in both columns:** add a 2-Column Section,
  add a block into each column, assert both blocks' labels are present.
- **Accordion items / Slideshow slides / 3-Column Carousel items:** add an
  Accordion block and add a second Accordion Item; add a Slideshow block and
  add a slide; add a 3-Column Carousel block and add a second item — assert
  each added item's label appears.
- **Validation:** publish the custom page form with an empty Page Title —
  assert native/Drupal validation blocks the submit (URL stays on /node/add/).

### 7. Miscellaneous
- Search box / site search if one exists on the homepage (assert results page
  loads without 404).
- The "Manage" toolbar dropdown (and MTPC Administration links) resolve to real
  pages (no 404).
- Front-page/current node rendering of a Navigation Menu block placed on a
  published page (assert the menu appears on the rendered node).

## Expected plan shape

- One standalone test case (TC-N) per coverage item above, with an explicit
  Priority (high for lifecycle/composer operations, medium for listing/admin
  reads), explicit Steps, and Expected result.
- Indicate Dependencies only where truly required (prefer none).
- Use `[explore: URL]` / `[explore-expanded: URL]` markers for any page you
  need that is not already snapshotted (e.g. `/admin/content/media`,
  `/admin/people`, `/admin/structure/*`, a rendered `/node/<id>`).
- Every test base URL is `https://builder-clean.docker-uat01.ust.hk`.
