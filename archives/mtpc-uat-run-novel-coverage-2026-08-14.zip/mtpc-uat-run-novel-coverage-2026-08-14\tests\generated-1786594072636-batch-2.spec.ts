import { test, expect, type Page } from '@playwright/test';
import { revealButton, clickButton, addSection, openAdvancedOptions, expectBlockLabel, publishPage } from '../../templates/form-helpers';
test.afterEach(async ({ page }, testInfo) => {
  const { mkdirSync } = await import('node:fs');
  const { join } = await import('node:path');
  const dir = process.env.SCREENSHOT_OUTPUT || join(process.cwd(), 'run', 'screenshots');
  try { mkdirSync(dir, { recursive: true }); } catch {}
  const name = testInfo.title.replace(/[^a-z0-9]/gi, '_').toLowerCase();
  const suffix = testInfo.status === 'passed' ? 'pass' : 'fail';
  await page.screenshot({ path: join(dir, name + '_' + suffix + '.png'), fullPage: true }).catch(() => {});
});


async function createAndPublishPage(page: Page, title: string): Promise<string> {
  await page.goto('/node/add/custom_page/mtpc');
  await page.getByRole('textbox', { name: 'Page Title' }).fill(title);
  return publishPage(page);
}

async function filterByTitle(page: Page, title: string) {
  await page.goto('/admin/mtpc/content');
  await page.locator('#edit-title').fill(title);
  await page.getByRole('button', { name: 'Filter' }).click();
  await page.getByRole('row').filter({ hasText: title }).first().waitFor({ timeout: 20000 });
}

async function applyBulkAction(page: Page, title: string, actionValue: string) {
  await filterByTitle(page, title);
  await page.locator('input[name="node_bulk_form[0]"]').first().check();
  await page.locator('select[name="action"]').first().selectOption(actionValue);
  await page.getByRole('button', { name: 'Apply to selected items' }).first().click();
  await page.locator('.messages--status').first().waitFor({ timeout: 20000 });
  await page.waitForTimeout(500);
}

test('TC-06 content-listing-bulk-publish-unpublish', async ({ page }) => {
  test.setTimeout(120000);
  const title = 'TC-06 Bulk ' + Date.now();
  await createAndPublishPage(page, title);

  await applyBulkAction(page, title, 'node_unpublish_action');
  let row = page.getByRole('table').first().getByRole('row').filter({ hasText: title });
  await expect(row).toContainText('Unpublished');

  await applyBulkAction(page, title, 'node_publish_action');
  row = page.getByRole('table').first().getByRole('row').filter({ hasText: title });
  await expect(row).toContainText('Published');
});

test('TC-07 content-listing-add-content-links', async ({ page }) => {
  await page.goto('/admin/mtpc/content');

  await page.locator('#block-custommenu a[href="/node/add/custom_page/mtpc"]').click();
  await expect(page).toHaveURL('/node/add/custom_page/mtpc');
  await expect(page.getByRole('button', { name: 'Publish Page' })).toBeVisible();

  await page.goBack();
  await page.locator('#block-custommenu a[href="/node/add/news/mtpc"]').click();
  await expect(page).toHaveURL('/node/add/news/mtpc');

  await page.goBack();
  await page.locator('#block-custommenu a[href="/node/add/mtpc_gallery/mtpc"]').click();
  await expect(page).toHaveURL('/node/add/mtpc_gallery/mtpc');

  await page.goBack();
  await page.locator('#block-custommenu a[href="/admin/mtpc/content?type=news"]').click();
  await expect(page).toHaveURL(/type=news/);
  await expect(page.locator('#edit-type option:checked')).toHaveText('News');
});

test('TC-08 media-admin-access-control', async ({ page }) => {
  await page.goto('/admin/mtpc/content');
  await page.locator('a[href="/admin/content/media"]').first().click();
  await expect(page).toHaveTitle(/^Media \|/);
  await expect(page.locator('h1').first()).toContainText('Media');

  await page.goto('/media/add');
  await expect(page).toHaveTitle(/^Add media item \|/);
  await expect(page.locator('h1').first()).toContainText('Add media item');
});

test('TC-09 add-menu-link', async ({ page }) => {
  const title = 'TC-09 Link ' + Date.now();
  await page.goto('/admin/structure/menu/manage/main/add');
  await expect(page.getByRole('heading', { name: 'Add menu link', level: 1 })).toBeVisible();

  await page.getByRole('textbox', { name: 'Menu link title' }).fill(title);
  await page.getByRole('textbox', { name: 'Link', exact: true }).fill('/style-guide');

  const parentSelect = page.getByRole('combobox', { name: 'Parent link' });
  if (await parentSelect.count() > 0) {
    const optionTexts = await parentSelect.first().locator('option').allInnerTexts();
    const match = optionTexts.find((o) => o.includes('Style Guide'));
    if (match) await parentSelect.first().selectOption({ label: match.trim() });
  }

  await page.getByRole('button', { name: 'Save' }).click();
  await expect(page.locator('.messages--status')).toContainText(/The menu link has been saved/, { timeout: 15000 });
  await expect(page).toHaveURL(/\/admin\/structure\/menu\/item\/\d+\/edit/);
  await expect(page.locator('#edit-title-0-value')).toHaveValue(title);
});

test.describe('TC-10 structure admin access control', () => {
  const urls = [
    { url: '/admin/structure/menu', title: /^Menus \|/ },
    { url: '/admin/structure/types', title: /^Content types \|/ },
    { url: '/admin/structure/block', title: /^Block layout \|/ },
    { url: '/admin/structure/views', title: /^Views \|/ },
    { url: '/admin/structure/taxonomy', title: /^Taxonomy \|/ },
  ];

  for (const { url, title } of urls) {
    test(`structure admin page loads: ${url}`, async ({ page }) => {
      await page.goto(url);
      await expect(page).toHaveTitle(title);
    });
  }

  test('All Menus link from content listing', async ({ page }) => {
    await page.goto('/admin/mtpc/content');
    await page.locator('#block-custommenu a[href="/admin/structure/menu"]').first().click();
    await expect(page).toHaveTitle(/^Menus \|/);
  });
});
