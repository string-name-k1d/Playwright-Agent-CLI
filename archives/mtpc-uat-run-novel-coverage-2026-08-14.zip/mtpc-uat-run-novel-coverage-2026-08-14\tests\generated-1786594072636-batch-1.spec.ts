import { test, expect } from '@playwright/test';
import { clickButton, addSection, publishPage } from '../../templates/form-helpers';
test.afterEach(async ({ page }, testInfo) => {
  const { mkdirSync } = await import('node:fs');
  const { join } = await import('node:path');
  const dir = process.env.SCREENSHOT_OUTPUT || join(process.cwd(), 'run', 'screenshots');
  try { mkdirSync(dir, { recursive: true }); } catch {}
  const name = testInfo.title.replace(/[^a-z0-9]/gi, '_').toLowerCase();
  const suffix = testInfo.status === 'passed' ? 'pass' : 'fail';
  await page.screenshot({ path: join(dir, name + '_' + suffix + '.png'), fullPage: true }).catch(() => {});
});


test.describe('Area 1 - Published page rendering & lifecycle', () => {
  test('TC-01. view-published-page-rendering', async ({ page }) => {
    await page.goto('/style-guide');

    expect(await page.title()).not.toContain('Page not found');
    await expect(page).toHaveURL('/style-guide');

    await expect(page.getByRole('heading', { name: 'Style Guide', level: 2 })).toBeVisible();
    await expect(page.getByRole('heading', { name: 'H1 - Lorem Ipsum is light heading', level: 1 })).toBeVisible();
    for (const level of [2, 3, 4, 5, 6]) {
      await expect(page.getByRole('heading', { level }).first()).toBeVisible();
    }

    await expect(page.getByRole('heading', { name: 'Bordered Table', level: 3 })).toBeVisible();
    const table = page.getByRole('table').filter({ has: page.getByRole('columnheader', { name: /Date/ }) }).first();
    await expect(table.getByRole('columnheader', { name: /Date/ }).first()).toBeVisible();
    await expect(table.getByRole('columnheader', { name: /Description/ }).first()).toBeVisible();
    await expect(table.getByRole('cell', { name: /May - Apr 2019/ }).first()).toBeVisible();

    await expect(page.getByRole('heading', { name: 'An Unordered List' })).toBeVisible();
    await expect(page.getByRole('heading', { name: 'An Ordered List' })).toBeVisible();
    await expect(page.getByRole('list').first()).toBeVisible();
    await expect(page.getByRole('listitem').first()).toBeVisible();

    const article = page.getByRole('article').first();
    await expect(article.getByRole('link', { name: 'Read More' }).first()).toBeVisible();
    await expect(article.getByRole('link', { name: 'Back' }).first()).toBeVisible();

    await expect(page.getByRole('blockquote').first()).toContainText(/blockquote - Lorem ipsum dolor sit amet/);
  });

  test('TC-02. edit-existing-published-page', async ({ page }) => {
    test.setTimeout(120000);
    const title = 'TC-02 Edit Me ' + Date.now();

    await page.goto('/node/add/custom_page/mtpc');
    await page.getByRole('textbox', { name: 'Page Title' }).fill(title);
    const nodeId = await publishPage(page);

    await page.goto('/node/' + nodeId + '/edit/mtpc');
    await expect(page.locator('#edit-title-0-value')).toHaveValue(title);
    await expect(page.getByRole('button', { name: 'Publish Page' })).toBeVisible();

    await page.getByRole('textbox', { name: 'Page Title' }).fill(title + ' EDITED');
    await publishPage(page);

    await expect(page.getByRole('heading', { name: title + ' EDITED' })).toBeVisible();
  });

  test('TC-03. delete-published-page', async ({ page }) => {
    test.setTimeout(120000);
    const title = 'TC-03 Delete Me ' + Date.now();

    await page.goto('/node/add/custom_page/mtpc');
    await page.getByRole('textbox', { name: 'Page Title' }).fill(title);
    const nodeId = await publishPage(page);

    await page.goto('/node/' + nodeId + '/delete');
    await expect(page.getByRole('heading', { level: 1 })).toContainText(
      `Are you sure you want to delete the content item ${title}?`
    );

    await page.getByRole('button', { name: 'Delete' }).click();
    await expect(page.getByText('has been deleted.')).toBeVisible({ timeout: 15000 });

    await page.goto('/admin/mtpc/content');
    await page.locator('#edit-title').fill(title);
    await page.locator('#edit-submit-mtpc-pages-contents').click();
    await page.waitForLoadState('networkidle');

    await expect(
      page.getByRole('table').getByRole('link', { name: title, exact: true })
    ).toHaveCount(0);
  });

  test('TC-04. unpublish-publish-toggle', async ({ page }) => {
    test.setTimeout(120000);
    const title = 'TC-04 Toggle ' + Date.now();

    await page.goto('/node/add/custom_page/mtpc');
    await page.getByRole('textbox', { name: 'Page Title' }).fill(title);
    const nodeId = await publishPage(page);

    await page.goto('/node/' + nodeId + '/edit/mtpc');
    await page.getByRole('checkbox', { name: 'Published' }).uncheck();
    await publishPage(page);

    await page.goto('/admin/mtpc/content');
    await page.locator('#edit-title').fill(title);
    await page.locator('#edit-submit-mtpc-pages-contents').click();
    await page.waitForLoadState('networkidle');
    let row = page
      .getByRole('table')
      .locator('tr')
      .filter({ has: page.getByRole('link', { name: title, exact: true }) });
    await expect(row.getByRole('cell').filter({ hasText: 'Unpublished' })).toBeVisible();

    await page.goto('/node/' + nodeId + '/edit/mtpc');
    await page.getByRole('checkbox', { name: 'Published' }).check();
    await publishPage(page);

    await page.goto('/admin/mtpc/content');
    await page.locator('#edit-title').fill(title);
    await page.locator('#edit-submit-mtpc-pages-contents').click();
    await page.waitForLoadState('networkidle');
    row = page
      .getByRole('table')
      .locator('tr')
      .filter({ has: page.getByRole('link', { name: title, exact: true }) });
    await expect(row.getByRole('cell').filter({ hasText: 'Published' })).toBeVisible();
  });
});

test.describe('Area 2 - Content listing operations', () => {
  test('TC-05. content-listing-sorting', async ({ page }) => {
    await page.goto('/admin/mtpc/content');

    const titleCells = page.getByRole('table').locator('tbody tr td:nth-child(2)');
    const before = await titleCells.allInnerTexts();

    await page.locator('a[href="?order=title&sort=asc"]').click();
    await page.waitForLoadState('networkidle');
    await expect(page).toHaveURL(/order=title&sort=asc/);
    const asc = await titleCells.allInnerTexts();
    expect([...asc].sort((a, b) => a.localeCompare(b))).toEqual(asc);

    await page.locator('a[href="?order=title&sort=desc"]').click();
    await page.waitForLoadState('networkidle');
    await expect(page).toHaveURL(/order=title&sort=desc/);
    const desc = await titleCells.allInnerTexts();
    expect([...desc].sort((a, b) => b.localeCompare(a))).toEqual(desc);

    expect(JSON.stringify(asc) === JSON.stringify(before)).toBe(false);
  });
});
